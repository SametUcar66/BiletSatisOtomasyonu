﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class AnaSayfa : Form
    {  
        string kullaniciTipi;
        public AnaSayfa(string kullaniciTipi)
        {
            InitializeComponent();
            this.kullaniciTipi = kullaniciTipi;
        }
      
        private void AnaSayfa_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Kullanıcı Türü: " + kullaniciTipi);
        }
    }
}
