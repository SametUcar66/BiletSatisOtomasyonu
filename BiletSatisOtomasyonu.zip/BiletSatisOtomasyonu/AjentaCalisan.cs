﻿using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class AjentaCalisan : UserControl
    {
        public AjentaCalisan()
        {
            InitializeComponent();
        }
    }
}