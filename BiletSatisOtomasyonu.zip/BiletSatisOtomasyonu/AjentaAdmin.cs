﻿using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class AjentaAdmin : UserControl
    {
        public AjentaAdmin()
        {
            InitializeComponent();
        }
    }
}