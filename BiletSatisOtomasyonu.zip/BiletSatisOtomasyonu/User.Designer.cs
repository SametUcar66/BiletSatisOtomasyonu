﻿using System.ComponentModel;

namespace BiletSatisOtomasyonu
{
    partial class User
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnSifreDegistir = new System.Windows.Forms.Button();
            this.lblAdSoyad = new System.Windows.Forms.Label();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTelefon = new System.Windows.Forms.Label();
            this.dgvBiletler = new System.Windows.Forms.DataGridView();
            this.lblBiletlerim = new System.Windows.Forms.Label();
            this.degiskenPanel = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBiletler)).BeginInit();
            this.degiskenPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(12, 538);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(254, 38);
            this.btnGuncelle.TabIndex = 0;
            this.btnGuncelle.Text = "Bilgileri Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            // 
            // btnSifreDegistir
            // 
            this.btnSifreDegistir.Location = new System.Drawing.Point(12, 494);
            this.btnSifreDegistir.Name = "btnSifreDegistir";
            this.btnSifreDegistir.Size = new System.Drawing.Size(254, 38);
            this.btnSifreDegistir.TabIndex = 2;
            this.btnSifreDegistir.Text = "Şifre Değiştir";
            this.btnSifreDegistir.UseVisualStyleBackColor = true;
            // 
            // lblAdSoyad
            // 
            this.lblAdSoyad.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblAdSoyad.Location = new System.Drawing.Point(29, 105);
            this.lblAdSoyad.Name = "lblAdSoyad";
            this.lblAdSoyad.Size = new System.Drawing.Size(247, 22);
            this.lblAdSoyad.TabIndex = 3;
            this.lblAdSoyad.Text = "Ad Soyad";
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(269, 495);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(63, 81);
            this.btnCikis.TabIndex = 4;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            // 
            // lblEmail
            // 
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblEmail.Location = new System.Drawing.Point(29, 127);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(247, 22);
            this.lblEmail.TabIndex = 5;
            this.lblEmail.Text = "Email";
            // 
            // lblTelefon
            // 
            this.lblTelefon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTelefon.Location = new System.Drawing.Point(29, 149);
            this.lblTelefon.Name = "lblTelefon";
            this.lblTelefon.Size = new System.Drawing.Size(247, 22);
            this.lblTelefon.TabIndex = 6;
            this.lblTelefon.Text = "Telefon";
            // 
            // dgvBiletler
            // 
            this.dgvBiletler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBiletler.Location = new System.Drawing.Point(16, 25);
            this.dgvBiletler.Name = "dgvBiletler";
            this.dgvBiletler.Size = new System.Drawing.Size(247, 223);
            this.dgvBiletler.TabIndex = 7;
            // 
            // lblBiletlerim
            // 
            this.lblBiletlerim.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBiletlerim.Location = new System.Drawing.Point(6, 0);
            this.lblBiletlerim.Name = "lblBiletlerim";
            this.lblBiletlerim.Size = new System.Drawing.Size(55, 22);
            this.lblBiletlerim.TabIndex = 8;
            this.lblBiletlerim.Text = "Biletlerim";
            // 
            // degiskenPanel
            // 
            this.degiskenPanel.Controls.Add(this.lblBiletlerim);
            this.degiskenPanel.Controls.Add(this.dgvBiletler);
            this.degiskenPanel.Location = new System.Drawing.Point(23, 189);
            this.degiskenPanel.Name = "degiskenPanel";
            this.degiskenPanel.Size = new System.Drawing.Size(290, 270);
            this.degiskenPanel.TabIndex = 9;
            this.degiskenPanel.TabStop = false;
            this.degiskenPanel.Text = "groupBox1";
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.degiskenPanel);
            this.Controls.Add(this.lblTelefon);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblAdSoyad);
            this.Controls.Add(this.btnSifreDegistir);
            this.Controls.Add(this.btnGuncelle);
            this.Name = "User";
            this.Size = new System.Drawing.Size(335, 580);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBiletler)).EndInit();
            this.degiskenPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.GroupBox degiskenPanel;

        private System.Windows.Forms.Label lblBiletlerim;

        private System.Windows.Forms.DataGridView dgvBiletler;

        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblTelefon;

        private System.Windows.Forms.Button btnCikis;

        private System.Windows.Forms.Button btnSifreDegistir;
        private System.Windows.Forms.Label lblAdSoyad;

        private System.Windows.Forms.Button btnGuncelle;

        #endregion
    }
}