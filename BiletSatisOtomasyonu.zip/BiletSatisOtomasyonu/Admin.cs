﻿using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class Admin : UserControl
    {
        public Admin()
        {
            InitializeComponent();
        }
    }
}