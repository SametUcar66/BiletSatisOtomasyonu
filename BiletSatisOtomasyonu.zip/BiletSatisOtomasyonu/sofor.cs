﻿using System;
using System.Data;
using System.Data.SQLite;
using System.IO; // Dosya yolu işlemleri için gerekli
using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class sofor : Form
    {
        // Veritabanı dosya yolu her formda standart olarak bu şekilde tanımlanacak
        string dbPath = Path.Combine(Application.StartupPath, "VeriTabani.db");

        public sofor()
        {
            InitializeComponent();
        }

        private void sofor_Load(object sender, EventArgs e)
        {
            SeferleriGetir();
        }

        private void SeferleriGetir()
        {
            try
            {
                // BAĞLANTIYI BURADA MANUEL OLUŞTURUYORUZ
                string connectionString = $"Data Source={dbPath};Version=3;";

                using (SQLiteConnection conn = new SQLiteConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                        SELECT 
                            e.Id, 
                            e.FromLocation || ' > ' || e.ToLocation as 'Rota',
                            e.Date || ' ' || e.Time as 'Tarih',
                            v.PlateNumber as 'Plaka',
                            e.Price
                        FROM Expeditions e
                        LEFT JOIN Vehicles v ON e.VehicleId = v.Id
                        WHERE e.IsActive = 1";

                    SQLiteDataAdapter da = new SQLiteDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvSeferler.DataSource = dt;

                    if (dgvSeferler.Columns["Id"] != null)
                    {
                        dgvSeferler.Columns["Id"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seferler yüklenirken hata: " + ex.Message);
            }
        }

        private void dgvSeferler_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSeferler.SelectedRows.Count > 0)
            {
                int expeditionId = Convert.ToInt32(dgvSeferler.SelectedRows[0].Cells["Id"].Value);
                string rota = dgvSeferler.SelectedRows[0].Cells["Rota"].Value.ToString();

                lblSeciliSefer.Text = rota + " - Yolcu Listesi";

                YolculariGetir(expeditionId);
            }
        }

        private void YolculariGetir(int expeditionId)
        {
            try
            {
                // BAĞLANTIYI TEKRAR BURADA OLUŞTURUYORUZ
                string connectionString = $"Data Source={dbPath};Version=3;";

                using (SQLiteConnection conn = new SQLiteConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                        SELECT 
                            SeatNumber as 'Koltuk',
                            PassengerName as 'Yolcu Adı',
                            PassengerGender as 'Cinsiyet',
                            CASE WHEN Status = 1 THEN 'Satıldı' ELSE 'Rezerve' END as 'Durum'
                        FROM Tickets
                        WHERE ExpeditionId = @ExpId
                        ORDER BY SeatNumber ASC";

                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ExpId", expeditionId);

                        SQLiteDataAdapter da = new SQLiteDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dgvYolcular.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Yolcular yüklenemedi: " + ex.Message);
            }
        }

        private void btnSeferBaslat_Click(object sender, EventArgs e)
        {
            if (dgvSeferler.SelectedRows.Count == 0) return;
            MessageBox.Show("Sefer başlatıldı! İyi yolculuklar. 🚌", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSeferBitir_Click(object sender, EventArgs e)
        {
            if (dgvSeferler.SelectedRows.Count == 0) return;

            if (MessageBox.Show("Seferi tamamlamak istediğine emin misin?", "Onay", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Sefer başarıyla tamamlandı. ✅", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}