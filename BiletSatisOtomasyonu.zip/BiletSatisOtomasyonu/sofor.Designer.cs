﻿using System.ComponentModel;

namespace BiletSatisOtomasyonu
{
    partial class sofor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();

            // Sol Taraf (Seferler)
            this.grpSeferler = new System.Windows.Forms.GroupBox();
            this.dgvSeferler = new System.Windows.Forms.DataGridView();
            this.lblSoforAdi = new System.Windows.Forms.Label();

            // Sağ Taraf (Yolcular ve İşlemler)
            this.grpYolcular = new System.Windows.Forms.GroupBox();
            this.dgvYolcular = new System.Windows.Forms.DataGridView();
            this.pnlIslemler = new System.Windows.Forms.Panel();
            this.btnSeferBaslat = new System.Windows.Forms.Button();
            this.btnSeferBitir = new System.Windows.Forms.Button();
            this.lblSeciliSefer = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.grpSeferler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeferler)).BeginInit();
            this.grpYolcular.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYolcular)).BeginInit();
            this.pnlIslemler.SuspendLayout();
            this.SuspendLayout();

            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Size = new System.Drawing.Size(1000, 600);
            this.splitContainer1.SplitterDistance = 400;
            this.splitContainer1.TabIndex = 0;

            // --- SOL PANEL ---
            this.lblSoforAdi.AutoSize = true;
            this.lblSoforAdi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSoforAdi.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblSoforAdi.Location = new System.Drawing.Point(10, 10);
            this.lblSoforAdi.Name = "lblSoforAdi";
            this.lblSoforAdi.Size = new System.Drawing.Size(160, 28);
            this.lblSoforAdi.TabIndex = 0;
            this.lblSoforAdi.Text = "Sürücü Paneli";

            this.grpSeferler.Controls.Add(this.dgvSeferler);
            this.grpSeferler.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpSeferler.Location = new System.Drawing.Point(10, 50);
            this.grpSeferler.Name = "grpSeferler";
            this.grpSeferler.Size = new System.Drawing.Size(380, 540);
            this.grpSeferler.TabIndex = 1;
            this.grpSeferler.TabStop = false;
            this.grpSeferler.Text = "Atandığım Seferler";

            this.dgvSeferler.AllowUserToAddRows = false;
            this.dgvSeferler.AllowUserToDeleteRows = false;
            this.dgvSeferler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSeferler.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvSeferler.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSeferler.Location = new System.Drawing.Point(3, 26);
            this.dgvSeferler.MultiSelect = false;
            this.dgvSeferler.Name = "dgvSeferler";
            this.dgvSeferler.ReadOnly = true;
            this.dgvSeferler.RowHeadersVisible = false;
            this.dgvSeferler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeferler.Size = new System.Drawing.Size(374, 511);
            this.dgvSeferler.TabIndex = 0;
            this.dgvSeferler.SelectionChanged += new System.EventHandler(this.dgvSeferler_SelectionChanged);

            this.splitContainer1.Panel1.Controls.Add(this.grpSeferler);
            this.splitContainer1.Panel1.Controls.Add(this.lblSoforAdi);

            // --- SAĞ PANEL ---
            this.lblSeciliSefer.AutoSize = true;
            this.lblSeciliSefer.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSeciliSefer.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblSeciliSefer.Location = new System.Drawing.Point(10, 10);
            this.lblSeciliSefer.Name = "lblSeciliSefer";
            this.lblSeciliSefer.Size = new System.Drawing.Size(268, 32);
            this.lblSeciliSefer.TabIndex = 0;
            this.lblSeciliSefer.Text = "Sefer Detayı ve Listesi";

            this.grpYolcular.Controls.Add(this.dgvYolcular);
            this.grpYolcular.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpYolcular.Location = new System.Drawing.Point(10, 50);
            this.grpYolcular.Name = "grpYolcular";
            this.grpYolcular.Size = new System.Drawing.Size(570, 440);
            this.grpYolcular.TabIndex = 1;
            this.grpYolcular.TabStop = false;
            this.grpYolcular.Text = "Yolcu Manifestosu";

            this.dgvYolcular.AllowUserToAddRows = false;
            this.dgvYolcular.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvYolcular.BackgroundColor = System.Drawing.Color.White;
            this.dgvYolcular.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvYolcular.Location = new System.Drawing.Point(3, 26);
            this.dgvYolcular.Name = "dgvYolcular";
            this.dgvYolcular.ReadOnly = true;
            this.dgvYolcular.RowHeadersVisible = false;
            this.dgvYolcular.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvYolcular.Size = new System.Drawing.Size(564, 411);
            this.dgvYolcular.TabIndex = 0;

            this.pnlIslemler.Controls.Add(this.btnSeferBitir);
            this.pnlIslemler.Controls.Add(this.btnSeferBaslat);
            this.pnlIslemler.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlIslemler.Location = new System.Drawing.Point(0, 500);
            this.pnlIslemler.Name = "pnlIslemler";
            this.pnlIslemler.Size = new System.Drawing.Size(596, 100);
            this.pnlIslemler.TabIndex = 2;

            this.btnSeferBaslat.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSeferBaslat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeferBaslat.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSeferBaslat.ForeColor = System.Drawing.Color.White;
            this.btnSeferBaslat.Location = new System.Drawing.Point(13, 25);
            this.btnSeferBaslat.Name = "btnSeferBaslat";
            this.btnSeferBaslat.Size = new System.Drawing.Size(180, 50);
            this.btnSeferBaslat.TabIndex = 0;
            this.btnSeferBaslat.Text = "Seferi Başlat";
            this.btnSeferBaslat.UseVisualStyleBackColor = false;
            this.btnSeferBaslat.Click += new System.EventHandler(this.btnSeferBaslat_Click);

            this.btnSeferBitir.BackColor = System.Drawing.Color.IndianRed;
            this.btnSeferBitir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeferBitir.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSeferBitir.ForeColor = System.Drawing.Color.White;
            this.btnSeferBitir.Location = new System.Drawing.Point(210, 25);
            this.btnSeferBitir.Name = "btnSeferBitir";
            this.btnSeferBitir.Size = new System.Drawing.Size(180, 50);
            this.btnSeferBitir.TabIndex = 1;
            this.btnSeferBitir.Text = "Seferi Tamamla";
            this.btnSeferBitir.UseVisualStyleBackColor = false;
            this.btnSeferBitir.Click += new System.EventHandler(this.btnSeferBitir_Click);

            this.splitContainer1.Panel2.Controls.Add(this.pnlIslemler);
            this.splitContainer1.Panel2.Controls.Add(this.grpYolcular);
            this.splitContainer1.Panel2.Controls.Add(this.lblSeciliSefer);

            // 
            // sofor (Form Adı Güncellendi)
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.splitContainer1);
            this.Name = "sofor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sürücü Paneli";
            this.Load += new System.EventHandler(this.sofor_Load);

            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.grpSeferler.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeferler)).EndInit();
            this.grpYolcular.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvYolcular)).EndInit();
            this.pnlIslemler.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox grpSeferler;
        private System.Windows.Forms.DataGridView dgvSeferler;
        private System.Windows.Forms.Label lblSoforAdi;
        private System.Windows.Forms.GroupBox grpYolcular;
        private System.Windows.Forms.DataGridView dgvYolcular;
        private System.Windows.Forms.Panel pnlIslemler;
        private System.Windows.Forms.Button btnSeferBitir;
        private System.Windows.Forms.Button btnSeferBaslat;
        private System.Windows.Forms.Label lblSeciliSefer; private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox2;
    }
}