﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace BiletSatisOtomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SQLiteConnection baglan = new SQLiteConnection("Data Source=VeriTabani.db; Version=3");
        SQLiteCommand cmd;

        private void button1_Click(object sender, EventArgs e)
        {
            string kullaniciTipi=null;
            try
            {
                baglan.Open();


                string sql = "SELECT * FROM Users WHERE Email='" + txtEmail.Text + "' AND PasswordHash='" + txtPsw.Text + "'";

                cmd = new SQLiteCommand(sql, baglan);

                SQLiteDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    int userTpye = Convert.ToInt32(dr["UserType"]);
                
                    switch (userTpye)
                    {
                        case 0:
                            MessageBox.Show("Yönetici Girişi Başarılı");
                            kullaniciTipi = "Yönetici";

                            break;
                        case 1:
                            MessageBox.Show("Ajenta Yöneticisi Girişi Başarılı");
                            kullaniciTipi = "Ajenta Yöneticisi";
                            break;
                        case 2:
                            MessageBox.Show("Acente Çalışanı Girişi Başarılı");
                            kullaniciTipi = "Ajenta Çalışanı";
                      
                            break;
                        case 3:
                            MessageBox.Show("Şoför Girişi Başarılı");
                            kullaniciTipi = "Şoför";
                         
                            break;
                        case 4:
                            MessageBox.Show("Kurumsal Müşteri Girişi Başarılı");
                            kullaniciTipi = "Kurumsal Müşteri";
                           
                            break;
                        case 5:
                            MessageBox.Show("Müşteri Girişi Başarılı");

                            kullaniciTipi = "Müşteri"; 
                           
                         
                            break;
                        default:
                            break;
                    }
                    AnaSayfa anaSayfa = new AnaSayfa(kullaniciTipi);
                    anaSayfa.Show();

                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre hatalı!");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu: " + ex.Message);
                throw;
            }
            finally
            {
 baglan.Close();
            }
           
        }
    }
}
