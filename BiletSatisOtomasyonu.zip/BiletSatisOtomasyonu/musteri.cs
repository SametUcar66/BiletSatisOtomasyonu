﻿using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class musteri : UserControl
    {
        public musteri()
        {
            InitializeComponent();
        }
    }
}