﻿using System.Windows.Forms;

namespace BiletSatisOtomasyonu
{
    public partial class User : UserControl
    {
        public User()
        {
            InitializeComponent();
        }
    }
}